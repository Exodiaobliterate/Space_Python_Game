import pygame
import Sprite

import sys

#initializes pygames modules for use
pygame.init()

#the colors of things like the screen and cube
color = (255, 212, 252)
rect_color = (255,0,0)

#the size of the screen display
canvas = pygame.display.set_mode((500, 500))

#the captions of the window for use
pygame.display.set_caption('Geeksforgeeks')

x = 200
y = 200

width = 20
height = 20

vel = 10
v = 5
m = 1

BLACK = (0,0,0)

#an image for background if wanted
bg_image = pygame.image.load("BG.png.png").convert_alpha()

Sprite_Sheet = pygame.image.load("Basic Guy.png").convert_alpha()
sprite_sheet_rect = Sprite_Sheet.get_rect()
Sprite_Sheet = Sprite.SpriteSheet(Sprite_Sheet)

platform1 = pygame.image.load("Platform.png.png").convert_alpha()
platform1_rect = platform1.get_rect()

def Draw_Bg():
    scaled = pygame.transform.scale(bg_image, (500, 500))
    canvas.blit(scaled, (0,0))

#creaate animation list
animation_list = []
animation_steps = [4, 4]
action = 0
last_update = pygame.time.get_ticks()
animation_cooldown = 150
frame = 0
step_counter = 0

#flipping
isflipped = False

#the bool keeping it running
running = True
jumping = False

for animation in animation_steps:
    temp_img_list = []
    for _ in range(animation):
       temp_img_list.append(Sprite_Sheet.get_image(step_counter, 32, 32, 3, BLACK))
       step_counter += 1
    animation_list.append(temp_img_list)
    

#the game lop that maeks this all posible
while running:
    pygame.time.delay(10)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT] and x>-30:
        x -= vel
        if not action == 1:
            action = 1
        print(x)

    if keys[pygame.K_RIGHT] and x < 440:
        x += vel
        if not action == 1:
            action = 1
        print(x)

    if not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]:
        action = 0

    if jumping == False:
        if sprite_sheet_rect.colliderect(platform1_rect):
            print("do something")
        y += 1
        
        if keys[pygame.K_SPACE]:
            jumping = True

    if jumping:
        F = (1 / 0.5)*m*(v**2)

        y -= F 
        v = v-1

        if v<0: 
            m =-1

        if v == -6:
            jumping = False

            v= 5
            m= 1
        
    #update background
    canvas.fill(color)
    
    #update anim
    current_time = pygame.time.get_ticks()
    if current_time - last_update >= animation_cooldown:
        frame += 1
        last_update = current_time
        if frame >= len(animation_list[action]):
            frame = 0

    #show frame image
    Draw_Bg()
    canvas.blit(animation_list[action][frame], (x, y))

    pygame.display.update()