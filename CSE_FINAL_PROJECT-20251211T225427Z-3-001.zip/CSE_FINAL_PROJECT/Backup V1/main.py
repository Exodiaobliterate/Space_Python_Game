import pygame

pygame.init()

isrunning = True
clicked = False

#the size of the screen display
canvas = pygame.display.set_mode((500, 500))

#the captions of the window for use
pygame.display.set_caption('Geeksforgeeks')

#the cookie
cookie = pygame.image.load("cookie.png.png").convert()
bakery = pygame.image.load("Bakery.png").convert()
cookie.set_colorkey((0, 0, 0))
cookie_scaled = pygame.transform.scale(cookie, (250, 250))
bakery_scaled = pygame.transform.scale(bakery, (120, 50))
cookie_position = pygame.Rect(250 - 125, 250 - 125, 250, 250)
bakery_positiom = pygame.Rect(375, 50, bakery_scaled.get_width(), bakery_scaled.get_height())

cps = 0

money = 199

RFont = pygame.font.SysFont("rage", 24, True, True)

lastTick = 0
cooldown_between_Ticks = 1000 #cooldown in miliseconds


while isrunning:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            isrunning = False
    keys = pygame.key.get_pressed()
    mouse_pos = pygame.mouse.get_pos()
    if event.type == pygame.MOUSEBUTTONDOWN and cookie_position.collidepoint(mouse_pos) and clicked == False:
        money += 1
        clicked = True
        print(str(money))
    elif event.type == pygame.MOUSEBUTTONUP and clicked == True:
        clicked = False

    if event.type == pygame.MOUSEBUTTONDOWN and bakery_positiom.collidepoint(mouse_pos) and money >= 200 and clicked == False:
        money -= 200
        cps += 10000
        clicked = True
    elif event.type == pygame.MOUSEBUTTONUP and clicked == False:
        clicked = False 

    text = RFont.render(str(money), True, (0, 0, 0))

    canvas.fill((255, 255, 255))
    canvas.blit(cookie_scaled, (125, 125))
    canvas.blit(text, (250, 100))
    if money == 200 or money >= 200:
        canvas.blit(bakery_scaled, (375, 50))

    currentime = pygame.time.get_ticks()
    if currentime - lastTick >= cooldown_between_Ticks:
        money += cps
        lastTick = currentime

    

    pygame.display.flip()
    pygame.display.update()