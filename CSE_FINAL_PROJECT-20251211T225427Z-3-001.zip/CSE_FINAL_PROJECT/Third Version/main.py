import pygame

import sys

#initializes pygames modules for use
pygame.init()

#the colors of things like the screen and cube
color = (255, 212, 252)
rect_color = (255,0,0)

#the size of the screen display
canvas = pygame.display.set_mode((500, 500))

#the captions of the window for use
pygame.display.set_caption('Geeksforgeeks')

x = 200
y = 200

width = 20
height = 20

vel = 10
v = 5
m = 1

#an image for background if wanted
image = pygame.image.load("Basic Guy.png")

#the bool keeping it running
running = True
jumping = False

#the game lop that maeks this all posible
while running:
    pygame.time.delay(10)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    keys = pygame.key.get_pressed()

    if keys[pygame.K_UP] and y > 0:
        y -= vel
    if keys[pygame.K_LEFT] and x>0:
        x -= vel
    if keys[pygame.K_DOWN] and y<500-height:
        y += vel
    if keys[pygame.K_RIGHT] and x < 500-width:
        x += vel

    if jumping == False:
        if keys[pygame.K_SPACE]:
            jumping = True

    if jumping:
        F = (1 / 2)*m*(v**2)

        y -= F

        v = v-1

        if v<0:
            m =-1

        if v == -6:
            jumping = False

            v= 5
            m= 1
    
    canvas.fill((0,0,0))
    pygame.draw.rect(canvas, rect_color, pygame.Rect(x,y,width,height))

    pygame.display.update()