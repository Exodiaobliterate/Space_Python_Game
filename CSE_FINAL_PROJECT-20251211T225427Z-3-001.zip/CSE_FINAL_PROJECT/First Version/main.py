import pygame

pygame.init()

color = (234, 212, 252)
position = (0,0)

canvas = pygame.display.set_mode((1000, 1000))

pygame.display.set_caption('Geeksforgeeks')

image = pygame.image.load("Design-Decoded-Smiley-Face-631 copy.png")

running = True

while running:

    canvas.fill(color)
    canvas.blit(image, dest = position)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.update()