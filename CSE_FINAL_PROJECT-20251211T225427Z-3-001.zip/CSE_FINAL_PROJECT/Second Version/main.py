import pygame

#initializes pygames modules for use
pygame.init()

#the colors of things like the screen and cube
color = (255, 212, 252)
rect_color = (255,0,0)

#the size of the screen display
canvas = pygame.display.set_mode((500, 500))

#the captions of the window for use
pygame.display.set_caption('Geeksforgeeks')

#an image for background if wanted
image = pygame.image.load("Design-Decoded-Smiley-Face-631 copy.png")

#the bool keeping it running
running = True

#the game lop that maeks this all posible
while running:

    canvas.fill(color)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    pygame.draw.rect(canvas, rect_color, pygame.Rect(30,30,60,60))

    pygame.display.update()