import pygame
import Sprite

import sys

#initializes pygames modules for use
pygame.init()

#the colors of things like the screen and cube
color = (255, 212, 252)
rect_color = (255,0,0)

#the size of the screen display
canvas = pygame.display.set_mode((980, 720))

#the captions of the window for use
pygame.display.set_caption('Geeksforgeeks')

x = 200
y = 200

width = 20
height = 20

vel = 10
v = 5
m = 1

BLACK = (0,0,0)

#an image for background if wanted
bg_image = pygame.image.load("BG.png.png").convert_alpha()

Sprite_Sheet = pygame.image.load("Basic Guy.png").convert_alpha()
Sprite_Sheet = Sprite.SpriteSheet(Sprite_Sheet)

platform1 = pygame.image.load("Platform.png.png").convert_alpha()
platform1_scaled = pygame.transform.scale(platform1, (300, 32))
platform1_rect = pygame.Rect(0, 355, platform1_scaled.get_width(), platform1_scaled.get_height())

platform2 = pygame.image.load("Platform.png.png").convert_alpha()
platform2_scaled = pygame.transform.scale(platform2, (300, 32))
platform2_rect = pygame.Rect(200, 355, platform2_scaled.get_width(), platform2_scaled.get_height())

def Draw_Bg():
    scaled = pygame.transform.scale(bg_image, (980, 720))
    canvas.blit(scaled, (0,0))

#creaate animation list
animation_list = []
animation_steps = [4, 4]
action = 0
last_update = pygame.time.get_ticks()
animation_cooldown = 150
frame = 0
step_counter = 0

#flipping
isflipped = False

#the bool keeping it running
running = True
jumping = False
istouchingfloor = False

for animation in animation_steps:
    temp_img_list = []
    for _ in range(animation):
       temp_img_list.append(Sprite_Sheet.get_image(step_counter, 32, 32, 3, BLACK))
       step_counter += 1
    animation_list.append(temp_img_list)

playerPOS = (0, 0)

#the game lop that maeks this all posible
while running:
    pygame.time.delay(10)

    Sprite_sheet_rect = pygame.Rect(x + 30, y - 42, 32, 74)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT] and x>-30:
        x -= vel
        if not action == 1:
            action = 1
        print(x)

    if keys[pygame.K_RIGHT] and x < 980:
        x += vel
        if not action == 1:
            action = 1
        print(x)

    if not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]:
        action = 0

    if jumping == False:
        if platform1_rect.colliderect(Sprite_sheet_rect) or platform2_rect.colliderect(Sprite_sheet_rect):
            y = y
            if not istouchingfloor:
                istouchingfloor = True
        elif not platform1_rect.colliderect(Sprite_sheet_rect) or not platform2_rect.colliderect(Sprite_sheet_rect) and jumping == True:
            y += 5
            if istouchingfloor:
                istouchingfloor = False
        
        if keys[pygame.K_SPACE] and istouchingfloor == True:
            jumping = True

    if jumping:
        F = (1 / 0.25)*m*(v**2) #jump height
        print(F)

        y -= F 
        jumping = False
        
    #update background
    canvas.fill(color)
    
    #update anim
    current_time = pygame.time.get_ticks()
    if current_time - last_update >= animation_cooldown:
        frame += 1
        last_update = current_time
        if frame >= len(animation_list[action]):
            frame = 0

    #show frame image
    Draw_Bg()
    canvas.blit(animation_list[action][frame], (x, y - 65))
    canvas.blit(platform1_scaled, (0, 355))
    canvas.blit(platform2_scaled, (200, 355))

    pygame.display.update()